package com.example.demo.zookeeper;
import java.io.IOException;
import java.net.InetAddress;
import java.util.concurrent.CountDownLatch;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.AsyncCallback.StatCallback;
import org.apache.zookeeper.KeeperException.Code;
import org.apache.zookeeper.data.Stat;

public class ZooKeeperConnection {
	
	
   private static ZooKeeper zoo;
   final CountDownLatch connectedSignal = new CountDownLatch(1);

   public ZooKeeper connect(String host) throws IOException,InterruptedException {   
      zoo = new ZooKeeper(host,5000,new Watcher() {
         public void process(WatchedEvent we) {
            if (we.getState() == KeeperState.SyncConnected) {
               connectedSignal.countDown();
            }
         }
      });
      connectedSignal.await();
      return zoo;
   }

   public void close() throws InterruptedException {
      zoo.close();
   }

   public static String create(ZooKeeperConnection conn,String path) throws KeeperException, InterruptedException {
	   
	   try {
		   String hostname = InetAddress.getLocalHost().getHostAddress();
			zoo = conn.connect(hostname);
			Stat stat = zoo.exists(path, true);
			if (stat != null) {
				return path;
			} else {
				System.out.println("Node does not exists");
				byte[] data = hostname.getBytes();
		         zoo = conn.connect(hostname);
		         zoo.create(path, data, ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
		         return path;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage()); // Catches error messages
		}
	   	return path;
	}
   
   
}