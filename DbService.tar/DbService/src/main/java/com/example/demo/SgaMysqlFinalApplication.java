		package com.example.demo;

import org.apache.zookeeper.KeeperException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.zookeeper.ZooKeeperConnection;

@SpringBootApplication
public class SgaMysqlFinalApplication {

	private static ZooKeeperConnection conn;

	public static void main(String[] args) {
		String path = "/MyFirstZnode";
		SpringApplication.run(SgaMysqlFinalApplication.class, args);
			try {
				conn.create(conn,path);
			} catch (KeeperException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	}

}