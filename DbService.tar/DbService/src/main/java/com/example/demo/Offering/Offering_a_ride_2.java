package com.example.demo.Offering;

public class Offering_a_ride_2 {
	
	private String date;
	private String rideid;
	private String name;
	private String source;
	private String destination;
	private String contact_details;
	private String time;
	private String amount;
	private String passenger1;
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	private String passenger2;
	private String passenger3;
	
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}

	public String getContact_details() {
		return contact_details;
	}
	public void setContact_details(String contact_details) {
		this.contact_details = contact_details;
	}
	
	public String getPassenger1() {
		return passenger1;
	}
	public void setPassenger1(String passenger1) {
		this.passenger1 = passenger1;
	}
	
	public String getPassenger2() {
		return passenger2;
	}
	public void setPassenger2(String passenger2) {
		this.passenger2 = passenger2;
	}
	
	public String getPassenger3() {
		return passenger3;
	}
	public void setPassenger3(String passenger3) {
		this.passenger3 = passenger3;
	}

	public String getRideid() {
		return rideid;
	}
	public void setRideid(String rideid) {
		this.rideid = rideid;
	}
	
	
}




//to
//from
//date
//contact details


//NEW-->
//NAME
//CONTACT DETAILS
//FROM
//TO
//DATE
//PASSENGER1
//PASSENGER3
//PASSENGER2

